package com.healthcare.gui;

import com.healthcare.dao.UserDAO;
import com.healthcare.model.User;
import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    private JTextField username;
    private JPasswordField password;
    private JComboBox<String> role;

    public LoginFrame() {
        setTitle("Online Health Care Management System");
        setSize(450,300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel p=new JPanel(new GridLayout(5,2,10,10));
        p.setBorder(BorderFactory.createEmptyBorder(30,40,30,40));

        p.add(new JLabel("Username:"));
        username=new JTextField(); p.add(username);

        p.add(new JLabel("Password:"));
        password=new JPasswordField(); p.add(password);

        p.add(new JLabel("Role:"));
        role=new JComboBox<String>(new String[]{"ADMIN","DOCTOR","PATIENT"}); p.add(role);

        JButton login=new JButton("LOGIN");
        JButton clear=new JButton("CLEAR");
        p.add(login); p.add(clear);

        JLabel title=new JLabel("ONLINE HEALTH CARE MANAGEMENT SYSTEM",SwingConstants.CENTER);
        add(title,BorderLayout.NORTH);
        add(p);

        clear.addActionListener(e->{username.setText("");password.setText("");});

        login.addActionListener(e->doLogin());
    }

    private void doLogin() {
        try {
            User u=new UserDAO().login(username.getText(),new String(password.getPassword()));
            if(u==null || !u.getRole().equals(role.getSelectedItem())) {
                JOptionPane.showMessageDialog(this,"Invalid username, password or role.");
                return;
            }
            dispose();
            if("ADMIN".equals(u.getRole())) new AdminDashboard().setVisible(true);
            else if("DOCTOR".equals(u.getRole())) new DoctorDashboard(u.getId()).setVisible(true);
            else new PatientDashboard(u.getId()).setVisible(true);
        } catch(Exception ex) {
            JOptionPane.showMessageDialog(this,"Database Error: "+ex.getMessage());
        }
    }
}
