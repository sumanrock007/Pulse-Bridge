package com.healthcare.gui;

import com.healthcare.dao.AppointmentDAO;
import com.healthcare.dao.MedicalRecordDAO;
import com.healthcare.model.MedicalRecord;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;

public class DoctorDashboard extends JFrame {
    private final int userId;
    private JTable table;
    private DefaultTableModel model;

    public DoctorDashboard(int userId) {
        this.userId=userId;
        setTitle("Doctor Dashboard");
        setSize(950,600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel top=new JPanel();
        JButton view=new JButton("Appointments");
        JButton approve=new JButton("Approve");
        JButton reject=new JButton("Reject");
        JButton record=new JButton("Add Medical Record");
        JButton logout=new JButton("Logout");
        top.add(view);top.add(approve);top.add(reject);top.add(record);top.add(logout);

        model=new DefaultTableModel();
        table=new JTable(model);
        add(top,BorderLayout.NORTH); add(new JScrollPane(table));

        view.addActionListener(e->load());
        approve.addActionListener(e->changeStatus("Approved"));
        reject.addActionListener(e->changeStatus("Rejected"));
        record.addActionListener(e->addRecord());
        logout.addActionListener(e->{dispose();new LoginFrame().setVisible(true);});
        load();
    }

    private void load() {
        try {
            model.setDataVector(new Object[]{"ID","Patient","Doctor","Date","Time","Reason","Status"},0);
            for(String[] a:new AppointmentDAO().getAll()) model.addRow(a);
        } catch(Exception e){JOptionPane.showMessageDialog(this,e.getMessage());}
    }

    private void changeStatus(String status) {
        int row=table.getSelectedRow();
        if(row<0){JOptionPane.showMessageDialog(this,"Select an appointment.");return;}
        try {
            int id=Integer.parseInt(model.getValueAt(row,0).toString());
            new AppointmentDAO().updateStatus(id,status);
            load();
        } catch(Exception e){JOptionPane.showMessageDialog(this,e.getMessage());}
    }

    private void addRecord() {
        try {
            String patient=JOptionPane.showInputDialog(this,"Patient ID:");
            String diagnosis=JOptionPane.showInputDialog(this,"Diagnosis:");
            String prescription=JOptionPane.showInputDialog(this,"Prescription:");
            String notes=JOptionPane.showInputDialog(this,"Notes:");
            if(patient==null||diagnosis==null)return;

            // Demo uses the logged-in user's id as doctor user_id.
            int doctorId=1;
            String sqlHint="Use the doctor_id mapped to this login in a production version.";
            new MedicalRecordDAO().add(new MedicalRecord(
                Integer.parseInt(patient),doctorId,diagnosis,prescription,notes,
                new Date(System.currentTimeMillis())));
            JOptionPane.showMessageDialog(this,"Medical record added.");
        } catch(Exception e){JOptionPane.showMessageDialog(this,"Invalid data: "+e.getMessage());}
    }
}
