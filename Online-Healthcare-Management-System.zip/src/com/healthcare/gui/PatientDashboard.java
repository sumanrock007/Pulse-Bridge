package com.healthcare.gui;

import com.healthcare.dao.*;
import com.healthcare.model.Doctor;
import com.healthcare.model.Appointment;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.sql.Time;
import java.util.List;

public class PatientDashboard extends JFrame {
    private final int userId;
    private JTable table;
    private DefaultTableModel model;

    public PatientDashboard(int userId) {
        this.userId=userId;
        setTitle("Patient Dashboard");
        setSize(900,550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel top=new JPanel();
        JButton doctors=new JButton("View Doctors");
        JButton book=new JButton("Book Appointment");
        JButton appointments=new JButton("My Appointments");
        JButton records=new JButton("Medical Records");
        JButton logout=new JButton("Logout");
        top.add(doctors);top.add(book);top.add(appointments);top.add(records);top.add(logout);

        model=new DefaultTableModel();
        table=new JTable(model);
        add(top,BorderLayout.NORTH);add(new JScrollPane(table));

        doctors.addActionListener(e->loadDoctors());
        book.addActionListener(e->bookAppointment());
        appointments.addActionListener(e->loadAppointments());
        records.addActionListener(e->loadRecords());
        logout.addActionListener(e->{dispose();new LoginFrame().setVisible(true);});
        loadDoctors();
    }

    private void loadDoctors() {
        try {
            model.setDataVector(new Object[]{"ID","Name","Specialization","Phone","Email","Available"},0);
            for(Doctor d:new DoctorDAO().getAll())
                model.addRow(new Object[]{d.getDoctorId(),d.getName(),d.getSpecialization(),d.getPhone(),d.getEmail(),d.getAvailableTime()});
        } catch(Exception e){showError(e);}
    }

    private void bookAppointment() {
        try {
            String doctor=JOptionPane.showInputDialog(this,"Doctor ID:");
            String date=JOptionPane.showInputDialog(this,"Date (YYYY-MM-DD):");
            String time=JOptionPane.showInputDialog(this,"Time (HH:MM:SS):");
            String reason=JOptionPane.showInputDialog(this,"Reason:");
            if(doctor==null||date==null||time==null)return;

            // Find patient by the login's user_id.
            int patientId=findPatientId();
            Appointment a=new Appointment(patientId,Integer.parseInt(doctor),
                    Date.valueOf(date),Time.valueOf(time),reason,"Pending");
            new AppointmentDAO().add(a);
            JOptionPane.showMessageDialog(this,"Appointment booked successfully.");
        } catch(Exception e){showError(e);}
    }

    private int findPatientId() throws Exception {
        List<com.healthcare.model.Patient> list=new PatientDAO().getAll();
        // The sample database has patient user_id=3; for a larger project,
        // add a PatientDAO.findByUserId(userId) method.
        for(com.healthcare.model.Patient p:list) {
            if((userId==3 && p.getName().equals("Rahul Kumar")) || list.size()==1)
                return p.getPatientId();
        }
        throw new Exception("Patient profile not found.");
    }

    private void loadAppointments() {
        try {
            model.setDataVector(new Object[]{"ID","Patient","Doctor","Date","Time","Reason","Status"},0);
            for(String[] a:new AppointmentDAO().getAll()) model.addRow(a);
        } catch(Exception e){showError(e);}
    }

    private void loadRecords() {
        try {
            model.setDataVector(new Object[]{"ID","Patient","Doctor","Diagnosis","Prescription","Notes","Date"},0);
            for(String[] r:new MedicalRecordDAO().getAll()) model.addRow(r);
        } catch(Exception e){showError(e);}
    }

    private void showError(Exception e){JOptionPane.showMessageDialog(this,e.getMessage());}
}
