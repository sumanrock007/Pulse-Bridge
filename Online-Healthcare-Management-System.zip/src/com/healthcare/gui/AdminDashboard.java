package com.healthcare.gui;

import com.healthcare.dao.*;
import com.healthcare.model.Doctor;
import com.healthcare.model.Patient;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AdminDashboard extends JFrame {
    private JTable table;
    private DefaultTableModel model;

    public AdminDashboard() {
        setTitle("Admin Dashboard");
        setSize(900,600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel top=new JPanel();
        JButton doctors=new JButton("Doctors");
        JButton patients=new JButton("Patients");
        JButton appointments=new JButton("Appointments");
        JButton records=new JButton("Medical Records");
        JButton logout=new JButton("Logout");
        top.add(doctors);top.add(patients);top.add(appointments);top.add(records);top.add(logout);

        model=new DefaultTableModel();
        table=new JTable(model);
        add(top,BorderLayout.NORTH);
        add(new JScrollPane(table));

        doctors.addActionListener(e->showDoctors());
        patients.addActionListener(e->showPatients());
        appointments.addActionListener(e->showAppointments());
        records.addActionListener(e->showRecords());
        logout.addActionListener(e->{dispose();new LoginFrame().setVisible(true);});

        showDoctors();
    }

    private void showDoctors() {
        try {
            model.setDataVector(new Object[]{"ID","Name","Specialization","Phone","Email","Available Time"},0);
            for(Doctor d:new DoctorDAO().getAll())
                model.addRow(new Object[]{d.getDoctorId(),d.getName(),d.getSpecialization(),d.getPhone(),d.getEmail(),d.getAvailableTime()});
        } catch(Exception e){error(e);}
    }

    private void showPatients() {
        try {
            model.setDataVector(new Object[]{"ID","Name","Age","Gender","Phone","Email","Address"},0);
            for(Patient p:new PatientDAO().getAll())
                model.addRow(new Object[]{p.getPatientId(),p.getName(),p.getAge(),p.getGender(),p.getPhone(),p.getEmail(),p.getAddress()});
        } catch(Exception e){error(e);}
    }

    private void showAppointments() {
        try {
            model.setDataVector(new Object[]{"ID","Patient","Doctor","Date","Time","Reason","Status"},0);
            for(String[] a:new AppointmentDAO().getAll()) model.addRow(a);
        } catch(Exception e){error(e);}
    }

    private void showRecords() {
        try {
            model.setDataVector(new Object[]{"ID","Patient","Doctor","Diagnosis","Prescription","Notes","Date"},0);
            for(String[] r:new MedicalRecordDAO().getAll()) model.addRow(r);
        } catch(Exception e){error(e);}
    }

    private void error(Exception e){JOptionPane.showMessageDialog(this,e.getMessage());}
}
