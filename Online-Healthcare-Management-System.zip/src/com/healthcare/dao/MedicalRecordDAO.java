package com.healthcare.dao;

import com.healthcare.model.MedicalRecord;
import com.healthcare.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MedicalRecordDAO {
    public void add(MedicalRecord m) throws Exception {
        String sql="INSERT INTO medical_records(patient_id,doctor_id,diagnosis,prescription,notes,record_date) VALUES(?,?,?,?,?,?)";
        try(Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)) {
            p.setInt(1,m.getPatientId()); p.setInt(2,m.getDoctorId());
            p.setString(3,m.getDiagnosis()); p.setString(4,m.getPrescription());
            p.setString(5,m.getNotes()); p.setDate(6,m.getRecordDate());
            p.executeUpdate();
        }
    }

    public List<String[]> getAll() throws Exception {
        List<String[]> list=new ArrayList<String[]>();
        String sql="SELECT m.record_id,p.name patient,d.name doctor,m.diagnosis,m.prescription,m.notes,m.record_date " +
                   "FROM medical_records m JOIN patients p ON m.patient_id=p.patient_id " +
                   "JOIN doctors d ON m.doctor_id=d.doctor_id ORDER BY m.record_date DESC";
        try(Connection c=DBConnection.getConnection(); PreparedStatement s=c.prepareStatement(sql);
            ResultSet r=s.executeQuery()) {
            while(r.next()) list.add(new String[]{
                ""+r.getInt("record_id"),r.getString("patient"),r.getString("doctor"),
                r.getString("diagnosis"),r.getString("prescription"),r.getString("notes"),
                ""+r.getDate("record_date")});
        }
        return list;
    }
}
