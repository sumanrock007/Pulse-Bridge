package com.healthcare.dao;

import com.healthcare.model.Appointment;
import com.healthcare.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDAO implements CRUDOperations<Appointment> {

    public void add(Appointment a) throws Exception {
        String sql="INSERT INTO appointments(patient_id,doctor_id,appointment_date,appointment_time,reason,status) VALUES(?,?,?,?,?,'Pending')";
        try(Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)) {
            p.setInt(1,a.getPatientId()); p.setInt(2,a.getDoctorId());
            p.setDate(3,a.getAppointmentDate()); p.setTime(4,a.getAppointmentTime());
            p.setString(5,a.getReason()); p.executeUpdate();
        }
    }

    public void update(Appointment a) throws Exception {
        String sql="UPDATE appointments SET appointment_date=?,appointment_time=?,reason=?,status=? WHERE appointment_id=?";
        try(Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)) {
            p.setDate(1,a.getAppointmentDate()); p.setTime(2,a.getAppointmentTime());
            p.setString(3,a.getReason()); p.setString(4,a.getStatus());
            p.setInt(5,a.getAppointmentId()); p.executeUpdate();
        }
    }

    public void delete(int id) throws Exception {
        try(Connection c=DBConnection.getConnection();
            PreparedStatement p=c.prepareStatement("DELETE FROM appointments WHERE appointment_id=?")) {
            p.setInt(1,id); p.executeUpdate();
        }
    }

    public List<String[]> getAll() throws Exception {
        List<String[]> list=new ArrayList<String[]>();
        String sql="SELECT a.appointment_id,p.name patient,d.name doctor,a.appointment_date,a.appointment_time,a.reason,a.status " +
                   "FROM appointments a JOIN patients p ON a.patient_id=p.patient_id " +
                   "JOIN doctors d ON a.doctor_id=d.doctor_id ORDER BY a.appointment_date";
        try(Connection c=DBConnection.getConnection(); PreparedStatement s=c.prepareStatement(sql);
            ResultSet r=s.executeQuery()) {
            while(r.next()) list.add(new String[]{
                ""+r.getInt("appointment_id"),r.getString("patient"),r.getString("doctor"),
                ""+r.getDate("appointment_date"),""+r.getTime("appointment_time"),
                r.getString("reason"),r.getString("status")});
        }
        return list;
    }

    public void updateStatus(int id,String status) throws Exception {
        try(Connection c=DBConnection.getConnection();
            PreparedStatement p=c.prepareStatement("UPDATE appointments SET status=? WHERE appointment_id=?")) {
            p.setString(1,status); p.setInt(2,id); p.executeUpdate();
        }
    }
}
