package com.healthcare.dao;

import com.healthcare.model.Doctor;
import com.healthcare.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DoctorDAO implements CRUDOperations<Doctor> {

    public void add(Doctor d) throws Exception {
        String sql = "INSERT INTO doctors(name,specialization,phone,email,available_time) VALUES(?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {
            p.setString(1,d.getName()); p.setString(2,d.getSpecialization());
            p.setString(3,d.getPhone()); p.setString(4,d.getEmail());
            p.setString(5,d.getAvailableTime()); p.executeUpdate();
        }
    }

    public void update(Doctor d) throws Exception {
        String sql = "UPDATE doctors SET name=?,specialization=?,phone=?,email=?,available_time=? WHERE doctor_id=?";
        try (Connection c=DBConnection.getConnection(); PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,d.getName()); p.setString(2,d.getSpecialization());
            p.setString(3,d.getPhone()); p.setString(4,d.getEmail());
            p.setString(5,d.getAvailableTime()); p.setInt(6,d.getDoctorId());
            p.executeUpdate();
        }
    }

    public void delete(int id) throws Exception {
        try (Connection c=DBConnection.getConnection();
             PreparedStatement p=c.prepareStatement("DELETE FROM doctors WHERE doctor_id=?")) {
            p.setInt(1,id); p.executeUpdate();
        }
    }

    public List<Doctor> getAll() throws Exception {
        List<Doctor> list = new ArrayList<Doctor>();
        try (Connection c=DBConnection.getConnection();
             PreparedStatement p=c.prepareStatement("SELECT * FROM doctors");
             ResultSet r=p.executeQuery()) {
            while(r.next())
                list.add(new Doctor(r.getInt("doctor_id"),r.getString("name"),
                    r.getString("specialization"),r.getString("phone"),
                    r.getString("email"),r.getString("available_time")));
        }
        return list;
    }
}
