package com.healthcare.model;

import java.sql.Date;

public class MedicalRecord {
    private int recordId;
    private int patientId;
    private int doctorId;
    private String diagnosis;
    private String prescription;
    private String notes;
    private Date recordDate;

    public MedicalRecord() {}

    public MedicalRecord(int patientId, int doctorId, String diagnosis,
                         String prescription, String notes, Date recordDate) {
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.diagnosis = diagnosis;
        this.prescription = prescription;
        this.notes = notes;
        this.recordDate = recordDate;
    }

    public int getRecordId() { return recordId; }
    public void setRecordId(int id) { recordId = id; }
    public int getPatientId() { return patientId; }
    public void setPatientId(int id) { patientId = id; }
    public int getDoctorId() { return doctorId; }
    public void setDoctorId(int id) { doctorId = id; }
    public String getDiagnosis() { return diagnosis; }
    public void setDiagnosis(String s) { diagnosis = s; }
    public String getPrescription() { return prescription; }
    public void setPrescription(String s) { prescription = s; }
    public String getNotes() { return notes; }
    public void setNotes(String s) { notes = s; }
    public Date getRecordDate() { return recordDate; }
    public void setRecordDate(Date d) { recordDate = d; }
}
