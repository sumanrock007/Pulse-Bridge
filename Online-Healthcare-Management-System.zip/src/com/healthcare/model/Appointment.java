package com.healthcare.model;

import java.sql.Date;
import java.sql.Time;

public class Appointment {
    private int appointmentId;
    private int patientId;
    private int doctorId;
    private Date appointmentDate;
    private Time appointmentTime;
    private String reason;
    private String status;

    public Appointment() {}

    public Appointment(int patientId, int doctorId, Date date, Time time,
                       String reason, String status) {
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.appointmentDate = date;
        this.appointmentTime = time;
        this.reason = reason;
        this.status = status;
    }

    public int getAppointmentId() { return appointmentId; }
    public void setAppointmentId(int id) { appointmentId = id; }
    public int getPatientId() { return patientId; }
    public void setPatientId(int id) { patientId = id; }
    public int getDoctorId() { return doctorId; }
    public void setDoctorId(int id) { doctorId = id; }
    public Date getAppointmentDate() { return appointmentDate; }
    public void setAppointmentDate(Date d) { appointmentDate = d; }
    public Time getAppointmentTime() { return appointmentTime; }
    public void setAppointmentTime(Time t) { appointmentTime = t; }
    public String getReason() { return reason; }
    public void setReason(String r) { reason = r; }
    public String getStatus() { return status; }
    public void setStatus(String s) { status = s; }
}
