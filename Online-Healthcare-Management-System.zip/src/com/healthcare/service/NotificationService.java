package com.healthcare.service;

public class NotificationService extends Thread {
    private volatile boolean running = true;

    @Override
    public void run() {
        while (running) {
            System.out.println("Background service: checking appointments...");
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                running = false;
            }
        }
    }

    public void stopService() {
        running = false;
        interrupt();
    }
}
