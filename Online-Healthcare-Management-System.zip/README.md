# Online Health Care Management System

A Java Swing + MySQL + JDBC based healthcare management project.

## Features
- Role-based login: Admin, Doctor, Patient
- Patient and doctor management
- Appointment booking and status update
- Medical record management
- JDBC database connectivity
- OOP: inheritance, polymorphism, encapsulation and interfaces
- Collections and generics
- Multithreading and synchronization
- Modular DAO/service/model architecture

## Requirements
- JDK 8 or later
- MySQL Server
- MySQL Connector/J
- IntelliJ IDEA, Eclipse or NetBeans

## Database Setup
1. Start MySQL.
2. Run `database/healthcare.sql`.
3. Open `src/com/healthcare/util/DBConnection.java`.
4. Change USER and PASSWORD if required.

## JDBC Driver
Add MySQL Connector/J to the project classpath.

## Run
Run:
`com.healthcare.Main`

## Demo Login
Admin: admin / admin123
Doctor: doctor1 / doctor123
Patient: patient1 / patient123

## Important
The sample project is designed for academic demonstration. Passwords are plain text only for local/demo use. A production system should use password hashing, proper authorization, validation, and secure configuration.

## GitHub Structure
database/     SQL database script
src/          Java source code
screenshots/  Project screenshots
README.md     Setup and execution guide
