# Online Health Care Management System

## Academic Project
Java Swing + JDBC + MySQL healthcare management system.

## Major Features
- Role-based authentication
- Admin dashboard
- Doctor dashboard
- Patient dashboard
- Doctor management
- Patient management
- Appointment booking
- Appointment status workflow
- Medical records
- Consultation fee
- MySQL database
- JDBC PreparedStatements
- DAO architecture
- OOP, inheritance and polymorphism
- Interface and generics
- Collections
- Multithreading and synchronization
- Exception handling

## Architecture
GUI -> Service -> DAO -> JDBC -> MySQL

## Requirements
- JDK 8+
- MySQL Server
- MySQL Connector/J
- IntelliJ IDEA / Eclipse / NetBeans

## Setup
1. Create/open the project.
2. Run `database/healthcare.sql` in MySQL.
3. Change MySQL username/password in `DBConnection.java`.
4. Add MySQL Connector/J.
5. Run `com.healthcare.Main`.

## Demo Accounts
Admin: admin / admin123
Doctor: doctor1 / doctor123
Patient: patient1 / patient123

## GitHub Submission
Upload the complete project, SQL file, README and screenshots.
Make the repository public or give reviewer access.

## Important
Credentials are demonstration values only. A real application should hash passwords and use secure configuration.
