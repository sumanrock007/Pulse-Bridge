package com.healthcare.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class DBConnection {
    private static final String URL="jdbc:mysql://localhost:3306/healthcare?useSSL=false&serverTimezone=UTC";
    private static final String USER="root";
    private static final String PASSWORD="root";

    private DBConnection(){}

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL,USER,PASSWORD);
    }
}
