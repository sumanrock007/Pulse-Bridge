package com.healthcare.gui;

import com.healthcare.dao.*;
import com.healthcare.model.MedicalRecord;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;

public class DoctorDashboard extends JFrame {
    int userId;DefaultTableModel model=new DefaultTableModel();JTable table=new JTable(model);
    public DoctorDashboard(int uid){
        userId=uid;setTitle("Doctor Dashboard");setSize(1050,600);setLocationRelativeTo(null);setDefaultCloseOperation(EXIT_ON_CLOSE);UI.style(this);
        JPanel bar=new JPanel();JButton a=UI.button("Appointments"),ok=UI.button("Approve"),no=UI.button("Reject"),done=UI.button("Complete"),rec=UI.button("Add Medical Record"),out=UI.button("Logout");
        for(JButton x:new JButton[]{a,ok,no,done,rec,out})bar.add(x);add(bar,BorderLayout.NORTH);add(new JScrollPane(table));
        a.addActionListener(e->appointments());ok.addActionListener(e->status("Approved"));no.addActionListener(e->status("Rejected"));done.addActionListener(e->status("Completed"));rec.addActionListener(e->record());out.addActionListener(e->{dispose();new LoginFrame().setVisible(true);});appointments();
    }
    void appointments(){try{model.setDataVector(new Object[]{"ID","Patient","Doctor","Date","Time","Reason","Status"},0);for(String[] x:new AppointmentDAO().all())model.addRow(x);}catch(Exception e){UI.error(this,e);}}
    void status(String s){
        int row=table.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select appointment.");return;}
        try{new AppointmentDAO().status(Integer.parseInt(model.getValueAt(row,0).toString()),s);appointments();}catch(Exception e){UI.error(this,e);}
    }
    void record(){
        try{
            String p=JOptionPane.showInputDialog(this,"Patient ID:");String d=JOptionPane.showInputDialog(this,"Doctor ID:");
            String diag=JOptionPane.showInputDialog(this,"Diagnosis:");String pre=JOptionPane.showInputDialog(this,"Prescription:");
            String notes=JOptionPane.showInputDialog(this,"Notes:");
            if(p==null||d==null||diag==null)return;
            new MedicalRecordDAO().add(new MedicalRecord(Integer.parseInt(p),Integer.parseInt(d),diag,pre,notes,new Date(System.currentTimeMillis())));
            JOptionPane.showMessageDialog(this,"Medical record saved.");
        }catch(Exception e){UI.error(this,e);}
    }
}
