package com.healthcare;

import com.healthcare.gui.LoginFrame;
import com.healthcare.service.NotificationService;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        NotificationService service = new NotificationService();
        service.start();
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
