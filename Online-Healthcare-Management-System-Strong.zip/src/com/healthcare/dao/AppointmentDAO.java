package com.healthcare.dao;

import com.healthcare.model.Appointment;
import com.healthcare.util.DBConnection;
import java.sql.*;
import java.util.*;

public class AppointmentDAO implements CRUDOperations<Appointment>{
    public void add(Appointment a)throws Exception{
        String q="INSERT INTO appointments(patient_id,doctor_id,appointment_date,appointment_time,reason) VALUES(?,?,?,?,?)";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(q)){
            p.setInt(1,a.getPatientId());p.setInt(2,a.getDoctorId());p.setDate(3,a.getDate());p.setTime(4,a.getTime());
            p.setString(5,a.getReason());p.executeUpdate();
        }
    }
    public void update(Appointment a)throws Exception{}
    public void delete(int id)throws Exception{
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM appointments WHERE appointment_id=?")){
            p.setInt(1,id);p.executeUpdate();
        }
    }
    public void status(int id,String s)throws Exception{
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement("UPDATE appointments SET status=? WHERE appointment_id=?")){
            p.setString(1,s);p.setInt(2,id);p.executeUpdate();
        }
    }
    public List<String[]> all()throws Exception{
        List<String[]>x=new ArrayList<>();
        String q="SELECT a.appointment_id,p.name patient,d.name doctor,a.appointment_date,a.appointment_time,a.reason,a.status "+
                 "FROM appointments a JOIN patients p ON a.patient_id=p.patient_id JOIN doctors d ON a.doctor_id=d.doctor_id ORDER BY a.appointment_date";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(q);ResultSet r=p.executeQuery()){
            while(r.next())x.add(new String[]{""+r.getInt(1),r.getString(2),r.getString(3),""+r.getDate(4),""+r.getTime(5),r.getString(6),r.getString(7)});
        }return x;
    }
}
