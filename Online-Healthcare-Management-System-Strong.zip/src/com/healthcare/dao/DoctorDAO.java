package com.healthcare.dao;

import com.healthcare.model.Doctor;
import com.healthcare.util.DBConnection;
import java.sql.*;
import java.util.*;

public class DoctorDAO implements CRUDOperations<Doctor> {
    public void add(Doctor d)throws Exception{
        String q="INSERT INTO doctors(name,specialization,phone,email,available_time,consultation_fee) VALUES(?,?,?,?,?,?)";
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement(q)){
            p.setString(1,d.getName());p.setString(2,d.getSpecialization());p.setString(3,d.getPhone());
            p.setString(4,d.getEmail());p.setString(5,d.getAvailableTime());p.setDouble(6,d.getFee());p.executeUpdate();
        }
    }
    public void update(Doctor d)throws Exception{}
    public void delete(int id)throws Exception{
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement("DELETE FROM doctors WHERE doctor_id=?")){
            p.setInt(1,id);p.executeUpdate();
        }
    }
    public List<Doctor> all()throws Exception{
        List<Doctor> x=new ArrayList<>();
        try(Connection c=DBConnection.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM doctors");ResultSet r=p.executeQuery()){
            while(r.next())x.add(new Doctor(r.getInt("doctor_id"),r.getString("name"),r.getString("specialization"),
            r.getString("phone"),r.getString("email"),r.getString("available_time"),r.getDouble("consultation_fee")));
        }return x;
    }
}
