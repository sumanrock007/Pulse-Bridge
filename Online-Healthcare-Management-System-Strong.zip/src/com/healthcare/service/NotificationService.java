package com.healthcare.service;

public class NotificationService extends Thread {
    private boolean running=true;
    public void run(){
        while(running){
            System.out.println("[Background Thread] Appointment reminder service running...");
            try{Thread.sleep(5000);}catch(InterruptedException e){running=false;}
        }
    }
    public synchronized void stopService(){running=false;interrupt();}
}
